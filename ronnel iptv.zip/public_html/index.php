<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ronnel IPTV</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      font-family: 'Roboto', sans-serif;
    }

    nav {
      background-color: #000000;
      padding: 0 0 95px;
    }

    .nav-wrapper {
      padding: 0 20px;
    }

    .brand-logo {
      font-size: 2.5rem;
      color:#fff
    }
    .brand-logo-channel {
      font-size: 2.5rem;
      color:#ffffff
    }
    .brand-logo-others {
      font-size: 2.5rem;
      color:#000000
    }
    .brand-logo-contact {
      font-size: 2.5rem;
      color:#000000
    }
    .slogan {
      font-size: 1.5rem;
      color: #ffffff;
    }

    .section {
      padding: 40px 0;
    }

    .container {
      width: 90%;
      max-width: 1200px;
      margin: 0 auto;
    }

    .card-panel {
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
    }

    .card-title {
      font-size: 1.5rem;
      margin-bottom: 20px;
    }

    .card-content p {
      margin: 0;
    }

    .footer {
      background-color: #000000;
      color: #fff;
      padding: 20px 0;
    }

    .footer p {
      margin: 0;
    }

    .footer .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo-gallery {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      grid-gap: 20px;
      justify-items: center;
    }

    .logo-card {
      position: relative;
      cursor: pointer;
      transition: transform 0.1s;
    }

    .logo-card:hover {
      transform: scale(1.2);
    }

    .logo-card img {
      max-width: 100%;
      height: auto;
    }

    .logo-modal {
      max-width: 500px;
      width: 90%;
    }
  </style>
</head>
<body>
  <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo" id="logo-link">
        <img class="" src="logo.png" style="padding-top: 5%; padding-left: 30px; height: 100%; width: 100%;">
      </a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="#features">Features</a></li>
        <li><a href="#channels">Channels</a></li>
        <li><a href="#contact">Contact</a></li>
      </ul>
    </div>
  </nav>

  <section id="hero" class="section black">
    <div class="container">
      <h1 class="brand-logo">Welcome to Ronnel IPTV!</h1>
      <p class="slogan"><i class="material-icons">live_tv</i> &nbsp;Unleash Endless Entertainment at Your Fingertips!</p>
      <a href="#channels" class="btn-large waves-effect waves-light purple"></h1> Explore Channels</a>
    </div>
  </section>

  <section id="features" class="section grey lighten-2">
    <div class="container">
      <div class="row center">
        <div class="col s12 m4">
          <div class="card-panel">
            <i class="material-icons large">tv</i>
            <h4 class="card-title">High-Quality Channels</h4>
            <p>Enjoy a wide range of free channels with high-definition streaming for an immersive viewing experience.</p>
          </div>
        </div>
        <div class="col s12 m4">
          <div class="card-panel">
            <i class="material-icons large">playlist_play</i>
            <h4 class="card-title">Vast Channel Selection</h4>
            <p>Access a diverse selection of channels from various genres, including sports, news, entertainment, and more.</p>
          </div>
        </div>
        <div class="col s12 m4">
          <div class="card-panel">
            <i class="material-icons large">lock_open</i>
            <h4 class="card-title">No Subscription Required</h4>
            <p>My IPTV service is completely free for everyone. No payment or subscription plans needed to access the channels.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="channels" class="section black">
    <div class="container">
      <h2 class="brand-logo-channel center-align">Top Local Channels</h2>
      <div class="row center">
        <div class="col s12 m6 l4">
          <div class="card-panel logo-card">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Kapamilya_Channel_Logo_2020.svg/240px-Kapamilya_Channel_Logo_2020.svg.png" alt="Channel 1">
            <p>Premiere Philippine network offering quality entertainment, news, and education. Captivating dramas, engaging shows, reliable news.</p>
          </div>
        </div>
        <div class="col s12 m6 l4">
          <div class="card-panel logo-card">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/c/c0/GMA_Network_Logo_Vector.svg/140px-GMA_Network_Logo_Vector.svg.png" alt="Channel 2">
            <p>GMA 7 is a leading television network in the Philippines, known for its popular entertainment and trusted news programs.</p>
          </div>
        </div>
        <div class="col s12 m6 l4">
          <div class="card-panel logo-card">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/TV5_%28Philippines%29_logo.svg/65px-TV5_%28Philippines%29_logo.svg.png" alt="Channel 3">
            <p>TV5: Quality entertainment, news, and sports. Engaging programming that resonates with viewers.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section id="others" class="section">
    <div class="container">
      <h2 class="brand-logo-others center-align">HD Premium Channels</h2>
      <div class="logo-gallery">
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/54/American_Broadcasting_Company_Logo.svg/150px-American_Broadcasting_Company_Logo.svg.png" alt="Logo 1">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/TNT_%28TV_Channel%29.svg/150px-TNT_%28TV_Channel%29.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/en/thumb/d/d2/NBA_TV.svg/150px-NBA_TV.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top:30%" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/UFC_Logo.svg/150px-UFC_Logo.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/WWE_%282014%29_logo.svg/150px-WWE_%282014%29_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/2018_Animal_Planet_logo.svg/150px-2018_Animal_Planet_logo.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://i.ibb.co/mb59FX3/Game-Show-Central.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/2S2wXPp/pba-rush.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/en/thumb/2/2b/Cinemo_logo_vectorized.svg/150px-Cinemo_logo_vectorized.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/vJkNZZx/Pinoy-Box-Office-logo.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/en/thumb/6/6d/Cinema_One_2013_logo.svg/150px-Cinema_One_2013_logo.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/NBC_Sports_stacked_logo_%282012-present%29.svg/150px-NBC_Sports_stacked_logo_%282012-present%29.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/National_Geographic_Wild_logo.svg/150px-National_Geographic_Wild_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/OneSportsPlus_logo.svg/150px-OneSportsPlus_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/de/HBO_logo.svg/150px-HBO_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/en/thumb/b/b7/Sky_Sports_logo_2020.svg/150px-Sky_Sports_logo_2020.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/LzPxd1X/Supersport2012.jpg">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/CVxLDYP/Hits-movies-logo.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 20px" src="https://i.ibb.co/jHJTZB3/Viva-TV-logo.jpg">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px"src="https://i.ibb.co/xhCYnwx/Animaxlogo-20160701.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e9/Asian_Food_Network.svg/150px-Asian_Food_Network.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://i.ibb.co/pyNfJcV/BBC-Earth-logo.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/7Y19X0z/Discovery-asia.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 20px" src="https://upload.wikimedia.org/wikipedia/en/thumb/f/ff/DreamWorks_Animation_SKG_logo_with_fishing_boy.svg/150px-DreamWorks_Animation_SKG_logo_with_fishing_boy.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/n75DYMH/611-cinemax.png">
        </div>
        <div class="logo-card">
          <img src="https://i.ibb.co/Mg7T22b/MTV.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Cartoon_Network_2010_logo.svg/150px-Cartoon_Network_2010_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/ESPN_wordmark.svg/150px-ESPN_wordmark.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/KBS_World_(2009).svg/150px-KBS_World_(2009).svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Nickelodeon_2009_logo.svg/150px-Nickelodeon_2009_logo.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 50px" src="https://i.ibb.co/F3r3fwT/7imquVM.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/0yq2yRy/CCTN-Cebu-logo.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/Ws29F3B/AMcUJWw.png">
        </div>
        <div class="logo-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7b/Wish_107.5_%282015%29.svg/150px-Wish_107.5_%282015%29.svg.png">
        </div>
        <div class="logo-card">
          <img style="padding-top: 50px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Showtime.svg/150px-Showtime.svg.png">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/VcTpmdm.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/Nmb2KSW.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/TxiqMDd.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/wBiVaud.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/swiKOLp.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/mjq3Bnq.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/hlXAbJj.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/HXH2dI4.jpg">
        </div>
        <div class="logo-card">
          <img src="https://i.imgur.com/mpjkoXr.jpg">
        </div>
        <div class="logo-card">
          <img style="padding-top: 30px" src="https://i.ibb.co/drrk8bP/Image.png">
        </div>
        <div class="logo-card">
          <img src="https://i.ibb.co/3sbVjvS/aniplus.jpg">
        </div>

        <!-- Add more logo cards as needed -->
      </div>
    </div>
  </section>
  
  <?php
    require 'vendor/autoload.php'; // Include PHPMailer library

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $name = $_POST['name'];
        $v_email = $_POST['v_email'];
        $message = $_POST['message'];

        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);

        try {
            // Configure SMTP settings
            $mail->isSMTP();
            $mail->Host = 'mail0.serv00.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'ronnel-iptv@ronnel-iptv.serv00.net';
            $mail->Password = '5rp2eeph3k@Ultimatep455w0rd';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 25;

            // Set email content and recipient
            $mail->setFrom('ronnel-iptv@ronnel-iptv.serv00.net', $name);
            $mail->addAddress('storagedrive0608@gmail.com', 'Storage Drive');
            $mail->Subject = 'New Message from IPTV Website';
            $mail->Body = "Email: " . $v_email . "\nMessage: " . $message;

            // Send the email
            $mail->send();

            // Email sent successfully
            echo '<script>
                    Swal.fire({
                        title: "Success",
                        text: "Message sent successfully!",
                        icon: "success",
                        showConfirmButton: false,
                        timer: 2000 // 2 seconds
                    }).then(function() {
                        window.location = "index.php";
                    });
                  </script>';
        } catch (Exception $e) {
            // Error occurred while sending email
            echo '<script>
                    Swal.fire({
                        title: "Error",
                        text: "Message could not be sent. Error: ' . $mail->ErrorInfo . '",
                        icon: "error",
                        showConfirmButton: true
                    });
                  </script>';
        }
    }
?>

  <section id="contact" class="section grey lighten-4">
    <div class="container">
      <h2 class="brand-logo-contact center-align">Contact Me!</h2>
      <div class="row">
        <div class="col s12 m6 offset-m3">
          <div class="card">
            <div class="card-content">
              <form id="contact-form" action="" method="POST">
                <div class="input-field">
                  <input type="text" id="name" name="name" required>
                  <label for="name">Name</label>
                </div>
                <div class="input-field">
                  <input type="email" id="v_email" name="v_email" required>
                  <label for="name">Email</label>
                </div>
                <div class="input-field">
                  <textarea class="materialize-textarea" id="message" name="message" required></textarea>
                  <label for="message">Message</label>
                </div>
                <button type="submit" class="btn waves-effect waves-light purple">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer class="footer">
    <div class="container">
      <p>&copy; 2023 Ronnel IPTV. All rights reserved.</p>
    </div>
  </footer>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
  <script>
    // Function to check if the device is mobile
    function isMobileDevice() {
      return (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
    }
  
    // Get the logo link element
    var logoLink = document.getElementById('logo-link');
  
    // Get the logo image element
    var logoImage = logoLink.querySelector('img');
  
    // Check if the device is mobile
    if (isMobileDevice()) {
      // Set image size to 100% for mobile devices
      logoImage.style.height = '100%';
      logoImage.style.width = '100%';
      logoImage.style.paddingLeft = '0px';
    } else {
      // Set image size to 75% for desktop devices
      logoImage.style.height = '75%';
      logoImage.style.width = '75%';
    }
  </script>
</body>
</html>