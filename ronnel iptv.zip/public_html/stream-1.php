<?php
$auth_server = file_get_contents('https://fp.visualsec.net:8445/player_api.php?username=iamronnel&password=Ultimatep455w0rd&action=get_live_streams');
preg_match('/103.105.213.251:8443(.*?)3.m3u8/s', $auth_server, $matches);
$token_grab = preg_replace('/\\\\/', '', $matches[1]);
file_put_contents("localtv_token.txt", $token_grab);
$token_file = file_get_contents("localtv_token.txt");

$url = "http://103.105.213.251:8443" . $token_file . $_GET["channel"] . ".m3u8";

$headers = get_headers($url);

if ($headers && strpos($headers[0], '200') !== false) {
    $final_url = $url;
} else {
    $final_url = 'https://github.com/pctechkid/IPTV-error/raw/main/error.mp4';
}

header("Location: " . $final_url);
?>
