<?php
$channel = $_GET["channel"] ?? '';

if ($channel === 'pba.rush') {
    $redirectUrl = 'https://live.chimerako.com/hls/pba_stream_720.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'gsc') {
    $redirectUrl = 'https://855649d1dca1413dad89e627e1727d97.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Samsung_GameShowCentral/playlist.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'cine.mo') {
    $redirectUrl = 'https://abscbn-ono.akamaized.net/midroll/amagi_hls_data_abscbnAAA-abscbn-cinemo/CDN/playlist.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'cinema.one') {
    $redirectUrl = 'https://cinemaone-abscbn-ono.amagi.tv/index_4.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'cinema.one') {
    $redirectUrl = 'https://cinemaone-abscbn-ono.amagi.tv/index_4.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'aniplus') {
    $redirectUrl = 'http://op-group1-swiftservehd-1.dens.tv/h/h114/S4/mnf.m3u8?app_type=web&userid=jjj&chname=ANIPLUS_HD';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'aniplus') {
    $redirectUrl = 'http://op-group1-swiftservehd-1.dens.tv/h/h114/S4/mnf.m3u8?app_type=web&userid=jjj&chname=ANIPLUS_HD';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'kbs') {
    $redirectUrl = 'https://wms4-kortv.akamaized.net/a_live/63719963/smil:20ch011.smil/playlist.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'cctn') {
    $redirectUrl = 'http://122.55.252.134:8443/live/bba5b536faeacb9b56a3239f1ee8e3b3/1.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else if ($channel === 'wish1075') {
    $redirectUrl = 'https://untv.mmdlive.lldns.net/untv/f55dcf9ae0f542d6a7614893d0c2dd83/chunklist_b64000.m3u8';
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
} else {
    $alternateUrl = "https://tvnow.best/api/stream/michael.woodland.25@hotmail.com/324101/livetv.epg/{$channel}.m3u8";
    $defaultUrl = "https://tvnow.best/api/stream/alex_079@hotmail.com/896886/livetv.epg/{$channel}.m3u8";

    $redirectUrl = $defaultUrl;
    $ch = curl_init($redirectUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status !== 200) {
        $ch = curl_init($alternateUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    }

    if ($status !== 200) {
        $redirectUrl = "https://github.com/pctechkid/IPTV-error/raw/main/error.mp4";
    }
}

header("Location: $redirectUrl");
exit;
?>
